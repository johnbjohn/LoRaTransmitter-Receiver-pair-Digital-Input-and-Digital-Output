Microcontroller used - STM32F103


MAIN TASK- Checks the status of DI and send it to the receiver  

POINTS TO BE NOTED
> Choose frequency,Spreading Factor, Bandwith and Transmit power according to your usage
