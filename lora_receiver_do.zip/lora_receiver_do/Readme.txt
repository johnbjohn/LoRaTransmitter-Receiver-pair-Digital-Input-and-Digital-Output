Microcontroller used - STM32F103


MAIN TASK- Receives data from transmitter and perform action on DO according to DI of Transmitter on DO of receiver  

POINTS TO BE NOTED
> Choose frequency,Spreading Factor, Bandwith and Transmit power according to your usage
